if [[ $1 == "/dev/sd"* ]];then
	rm -rf $1
fi
