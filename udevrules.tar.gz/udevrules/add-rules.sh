cp -p ./99-disable-huawei-sd.rules /etc/udev/rules.d/
chmod +x ./1.sh
cp -p ./1.sh /etc/
udevadm control --reload-rules
